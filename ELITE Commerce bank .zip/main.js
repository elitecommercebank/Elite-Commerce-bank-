function handleLogin(event) {
  event.preventDefault(); // prevent from submission 
    }

  const numberInput = document.querySelector('input[type="text"]').value;
  const passwordInput = document.querySelector('input[type="password"]').value;

  const validnumber = '00100234027';
  const validPassword = '2020';

  if (numberInput === validnumber && passwordInput === validPassword) {
    document // show Dashboard 
    document.getElementById('dashboard').style.display = 'block';
  } else {
    alert('number or password');
  } 
    }